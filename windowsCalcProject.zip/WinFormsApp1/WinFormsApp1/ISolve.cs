﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    public interface ISolve
    {
        //declare methods to be used in the Solver class
        public void Accumulate(string s);
        public void Clear();
        public double Solve(string s);
    }
}
