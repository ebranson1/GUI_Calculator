﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        //make a solver object and strings for text formatting
        Solver solver = new Solver();
        string newLine = Environment.NewLine;
        string dashes = "---------------";

        public Form1()
        {
            InitializeComponent();
            //start with blank top and bottom separated by dashes
            display.Text = "" + newLine + dashes;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void display_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void buttonAC_Click(object sender, EventArgs e)
        {
            //call the clear method and return to blank display with dashes in the middle
            solver.Clear();
            display.Text = "" + newLine + dashes;
        }

        /*
         * for all button clicks, add the button value to the accumulated list, then display
         * all values in the list, then display the dashes
         */

        private void button1_Click(object sender, EventArgs e)
        {
            solver.Accumulate("1");
            display.Text = "";
            for(int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            solver.Accumulate("2");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            solver.Accumulate("3");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            solver.Accumulate("4");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            solver.Accumulate("5");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            solver.Accumulate("6");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button7_Click(object sender, EventArgs e)
        {
            solver.Accumulate("7");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button8_Click(object sender, EventArgs e)
        {
            solver.Accumulate("8");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button9_Click(object sender, EventArgs e)
        {
            solver.Accumulate("9");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void button0_Click(object sender, EventArgs e)
        {
            solver.Accumulate("0");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }

        private void buttonPos_Neg_Click(object sender, EventArgs e)
        {
            solver.Accumulate("-");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }

        private void buttonPercent_Click(object sender, EventArgs e)
        {
            solver.Accumulate("%");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }

        private void buttonDivide_Click(object sender, EventArgs e)
        {
            solver.Accumulate("/");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }

        private void buttonPlus_Click(object sender, EventArgs e)
        {
            solver.Accumulate("+");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }

        private void buttonMinus_Click(object sender, EventArgs e)
        {
            solver.Accumulate("-");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }

        private void buttonMultiply_Click(object sender, EventArgs e)
        {
            solver.Accumulate("*");
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;
        }
        private void buttonDecimal_Click(object sender, EventArgs e)
         {
              solver.Accumulate(".");
              display.Text = "";
              for (int i = 0; i < solver.accumulated.Count; i++)
              {
                 display.Text += solver.accumulated[i];
              }
              display.Text += newLine + dashes;
         }

        //call the solve method in the Solver class
        private void buttonEqual_Click(object sender, EventArgs e)
        {
            //first display everythin in the accumulated list on top of the dashes
            display.Text = "";
            for (int i = 0; i < solver.accumulated.Count; i++)
            {
                display.Text += solver.accumulated[i];
            }
            display.Text += newLine + dashes;

            //then do the math and show the result below the dashes
            double result = solver.Solve();

            display.Text += newLine + result;
        }

    }
}
