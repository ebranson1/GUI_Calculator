﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    class Solver
    {
        //create a list to hold the values (this way the size can change as operations are performed)
        public List<string> accumulated = new List<string>();
        public void Accumulate(string s)
        {
            //use .Add to add to the end of the list
            accumulated.Add(s);
        }
        public void Clear()
        {
            //the list structure has a built-in method for emptying the list
            accumulated.Clear();
        }


        //The below methods will be called by Solve

        //Find the number to the left of the operator
        double findLeft(int op)
        {
            //start with empty variable declarations
            string number = "";
            int numLength = 0;

            //the method is passed the operator's index (op), so move one index to the left to get to the start of the left number
            op--;
            for (int b = op; b >= 0; b--)
            {
                //check if it's a number (not another operator). If so, add to the numLength
                if (accumulated[b] != "*" && accumulated[b] != "/" && accumulated[b] != "%" && accumulated[b] != "+" && accumulated[b] != "-")
                {
                    numLength++;
                }
                //This else statement is for the case that the left number is negative, so the negative sign needs to be included in the number's length
                else if (accumulated[b] == "-" && (accumulated[b - 1] == "*" || accumulated[b - 1] == "/" || accumulated[b - 1] == "+" || accumulated[b - 1] == "-"))
                {
                    numLength++;
                    break;
                }
                else
                {
                    break;
                }
            }

            //build the number to be converted to a double
            for (int n = numLength; n > 0; n--)
            {
                number += accumulated[op + 1 - n];
            }

            //the number to the left of the given operator is returned as a double
            return Convert.ToDouble(number);
        }

        //Find the number to the right of the operator (works the same as findLeft)
        double findRight(int op)
        {
            //declare variables
            string number = "";
            int numLength = 0;

            //start one index to the right of the operator
            op++;
            //check for numbers and negative signs
            for (int b = op; b < accumulated.Count; b++)
            {
                if (accumulated[b] != "*" && accumulated[b] != "/" && accumulated[b] != "%" && accumulated[b] != "+" && accumulated[b] != "-")
                {
                    numLength++;
                }
                else if (accumulated[b] == "-" && (accumulated[b + 1] != "*" && accumulated[b + 1] != "/" && accumulated[b + 1] != "+" && accumulated[b + 1] != "-"))
                {
                    numLength++;
                }
                else
                {
                    break;
                }
            }

            //build the number
            for (int n = 0; n < numLength; n++)
            {
                number += accumulated[op + n];
            }

            //return the number to the right of the operator as a double
            return Convert.ToDouble(number);
        }

        //put a new value "num" in place of the numbers and operators which were used to calculate "num"
        List<string> putInPlace(List<string> accumulated, double num, int lengthLeft, int lengthRight, int spot)
        {
            //num is the value to be placed, lengthLeft is the number of indices to the left of the operator
            //lengthRight is the number of indices to the right of the operator, and spot is the index of the operator

            //if the number is negative, the minus sign will need to be added to a separate index for later calculations
            //so make the number positive, place a minus sign, and decrement lengthLeft
            if (num < 0)
            {
                num *= -1;
                accumulated[spot - lengthLeft] = "-";
                lengthLeft--;
            }

            //These try/catch parts check solve an issue with index out of bounds errors.
            //If the first or last index in the list has been calculated to be a number of length > 1,
            //it will only take up 1 index because it's a double that's been converted to a string, not an initially inputted string
            //if this is the case, lengthLeft or lengthRight needs to be = to 1, so they are set as such if an error is thrown
            try
            {
                accumulated[spot - lengthLeft] = Convert.ToString(num);
            }
            catch (Exception)
            {
                lengthLeft = 1;
                accumulated[spot - lengthLeft] = Convert.ToString(num);
            }

            try
            {
                accumulated[spot + lengthRight] = accumulated[spot + lengthRight];
            }
            catch (Exception)
            {
                lengthRight = 1;
            }


            //remove all the values that were combined to become the calculated num
            for (int i = (spot + lengthRight); i > spot - lengthLeft; i--)
            {
                accumulated.RemoveAt(i);
            }

            //return the rearranged list
            return accumulated;
        }

        //This method goes through the list and finds all the operators, then performs the operations in order
        double doMath(List<string> accumulated)
        {
            //declare variables
            double left = 0;
            double right = 0;

            //the operators array holds the number of each operation that is in the accumulated list
            //the operators and their corresponding indices in the array are shown in the comment below the declaration
            int[] operators = new int[5] { 0, 0, 0, 0, 0 };
            // [0] [1] [2] [3] [4]
            // [*] [/] [%] [+] [-]


            //find all the operators in the accumulated list
            for (int i = 0; i < accumulated.Count; i++)
            {
                switch (accumulated[i])
                {
                    case "*":
                        operators[0] = operators[0] + 1;
                        break;
                    case "/":
                        operators[1] = operators[1] + 1;
                        break;
                    case "%":
                        operators[2] = operators[2] + 1;
                        break;
                    case "+":
                        operators[3] = operators[3] + 1;
                        break;
                    case "-":
                        //negative signs should not be counted. It is considered a negative sign, not a minus sign, if another operator is before it
                        if (i != 0)
                        {
                            if (accumulated[i - 1] != "*" && accumulated[i - 1] != "/" && accumulated[i - 1] != "+" && accumulated[i - 1] != "-")
                            {
                                operators[4] = operators[4] + 1;
                            }
                        }
                        break;
                    default:
                        break;
                }
            }

            //while there are still multiplication signs (operators[0] holds # of multiplication signs), perform multiplications
            int multLoop = 0;
            while (operators[0] != 0)
            {
                //increment multLoop to cycle through the list
                if (accumulated[multLoop] == "*")
                {
                    //find the numbers to the left and right of the * operator
                    left = findLeft(multLoop);
                    right = findRight(multLoop);
                    
                    //find the lengths of the numbers on the left and right of the operator so that it can be known
                    //how much of the list to delete in putInPlace
                    int lengthLeft = Convert.ToString(left).Length;
                    int lengthRight = Convert.ToString(right).Length;

                    //modify the list using putInPlace
                    accumulated = putInPlace(accumulated, left * right, lengthLeft, lengthRight, multLoop);

                    //decrement operators because one multiplication sign has been taken care of
                    operators[0] = operators[0] - 1;

                    //if multiplication is implemented, start the multLoop over again because there may be more multiplication signs
                    //and the list indices will have shifted after the operation was performed
                    multLoop = 0;
                }
                multLoop++;

            }

            //loop for division, same as multiplication
            int divLoop = 0;
            while (operators[1] != 0)
            {

                if (accumulated[divLoop] == "/")
                {
                    left = findLeft(divLoop);
                    right = findRight(divLoop);
                    int lengthLeft = Convert.ToString(left).Length;
                    int lengthRight = Convert.ToString(right).Length;
                    accumulated = putInPlace(accumulated, left / right, lengthLeft, lengthRight, divLoop);
                    operators[1] = operators[1] - 1;
                    divLoop = 0;
                }
                divLoop++;

            }

            //loop for percentage is a bit different
            int perLoop = 0;
            double perLeft;
            while (operators[2] != 0)
            {

                if (accumulated[perLoop] == "%")
                {
                    left = findLeft(perLoop);
                    int lengthLeft = Convert.ToString(left).Length;

                    //percentage does not operate on a value to the right
                    int lengthRight = 0;

                    //percentage operates on the value to the left of %, and the value to the left of the next left operator
                    //so perLeft finds the value to the left of the next left operator, which is lengthLeft indices away
                    perLeft = findLeft(perLoop - lengthLeft - 1);
                    accumulated = putInPlace(accumulated, (left * perLeft / 100), lengthLeft, lengthRight, perLoop);
                    operators[2] = operators[2] - 1;
                    perLoop = 0;
                }
                perLoop++;

            }

            //loop for addition, same as multiplication
            int addLoop = 0;
            while (operators[3] != 0)
            {

                if (accumulated[addLoop] == "+")
                {
                    left = findLeft(addLoop);
                    right = findRight(addLoop);
                    int lengthLeft = Convert.ToString(left).Length;
                    int lengthRight = Convert.ToString(right).Length;
                    accumulated = putInPlace(accumulated, left + right, lengthLeft, lengthRight, addLoop);
                    operators[3] = operators[3] - 1;
                    addLoop = 0;
                }
                addLoop++;

            }

            //loop for subtraction, same as multiplication
            int subLoop = 0;
            while (operators[4] != 0)
            {

                if (accumulated[subLoop] == "-")
                {
                    left = findLeft(subLoop);
                    right = findRight(subLoop);
                    int lengthLeft = Convert.ToString(left).Length;
                    int lengthRight = Convert.ToString(right).Length;
                    accumulated = putInPlace(accumulated, left - right, lengthLeft, lengthRight, subLoop);
                    operators[4] = operators[4] - 1;
                    subLoop = 0;
                }
                subLoop++;

            }


            double result;

            //the result is either the only value in the list (index 0)
            //or is negative, so index 0 = "-" and the value is in index 1
            if (accumulated[0] == "-")
            {
                result = Convert.ToDouble(accumulated[1]) * -1;
            }
            else
            {
                result = Convert.ToDouble(accumulated[0]);
            }

            return result;
        }

        public double Solve()
        {
            return doMath(accumulated) ;
        }
    }
}
